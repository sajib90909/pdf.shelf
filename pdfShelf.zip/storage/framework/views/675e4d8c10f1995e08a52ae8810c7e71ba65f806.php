<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav class="navbar navbar-light justify-content-between bg-brand-light">
            <router-link class="navbar-brand" to="/">Pdf | Shelf</router-link>
            <div class="d-flex justify-content-sm-end">
                <app-top-search></app-top-search>
                <div class="ml-1">
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('profile', [ 'id' => \Illuminate\Support\Facades\Auth::id()])); ?>" class="btn btn-outline-primary ml-1 btn-sm">My Account</a>
                            <a class="btn btn-outline-dark ml-1 btn-sm" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary ml-1 btn-sm">Log in</a>

                            <?php if(Route::has('register')): ?>
                                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-dark ml-1 btn-sm">Register</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
        <div>
            <app-authenticate-user></app-authenticate-user>
            <router-view></router-view>
        </div>

        
        <footer class="d-flex justify-content-between text-white bg-dark">
            <!-- Grid container -->
            <div class="">
                <!-- Section: Social media -->
                <section class="">
                    <!-- Facebook -->
                    <a
                        class="btn btn-link btn-floating btn-lg text-light m-1"
                        href="https://facebook.com"
                        role="button"
                        target="_blank"
                        data-mdb-ripple-color="dark"
                    ><i class="fab fa-facebook-f"></i
                        ></a>

                    <!-- Twitter -->
                    <a
                        class="btn btn-link btn-floating btn-lg text-light m-1"
                        href="https://twitter.com"
                        role="button"
                        target="_blank"
                        data-mdb-ripple-color="dark"
                    ><i class="fab fa-twitter"></i
                        ></a>

                    <!-- Instagram -->
                    <a
                        class="btn btn-link btn-floating btn-lg text-light m-1"
                        href="https://www.instagram.com/"
                        role="button"
                        target="_blank"
                        data-mdb-ripple-color="dark"
                    ><i class="fab fa-instagram"></i
                        ></a>
                </section>
                <!-- Section: Social media -->
            </div>
            <!-- Grid container -->

            <!-- Copyright -->
            <div class="text-light p-3">
                © 2020 Copyright Pdf | shelf
            </div>
            <!-- Copyright -->
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sajib/Dev/Projects/pdfself/resources/views/front/master.blade.php ENDPATH**/ ?>