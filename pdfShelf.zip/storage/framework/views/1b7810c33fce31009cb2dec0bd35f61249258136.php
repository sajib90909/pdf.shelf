<?php $__env->startSection('content'); ?>
    <iframe class="w-100 h-100" src="<?php echo e(asset('pdf/sample.pdf')); ?>"></iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sajib/Dev/Projects/pdfself/resources/views/front/viewBook.blade.php ENDPATH**/ ?>