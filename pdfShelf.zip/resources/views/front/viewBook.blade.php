@extends('master')
@section('content')
    <iframe class="w-100 h-100" src="{{ asset('pdf/sample.pdf') }}"></iframe>
@endsection
