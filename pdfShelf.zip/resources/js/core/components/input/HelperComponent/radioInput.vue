<template>

</template>

<script>
export default {
    name: "radioInput"
}
</script>

<style scoped>

</style>
