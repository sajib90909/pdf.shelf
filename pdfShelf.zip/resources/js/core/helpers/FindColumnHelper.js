export const findColumnData = (key, row) => {
    return row[key];
}
