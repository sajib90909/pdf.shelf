import Vue from "vue";

Vue.component('app-page-title', require('./components/pageTitle').default);
Vue.component('app-top-search', require('./front/components/HelperComponents/TopSearch').default);
